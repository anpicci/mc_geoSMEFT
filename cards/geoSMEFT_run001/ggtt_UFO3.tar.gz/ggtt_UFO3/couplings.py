# This file was automatically created by FeynRules 2.3.47
# Mathematica version: 13.1.0 for Mac OS X ARM (64-bit) (June 16, 2022)
# Date: Sat 16 Mar 2024 22:18:01


from object_library import all_couplings, Coupling

from function_library import complexconjugate, re, im, csc, sec, acsc, asec, cot



GC_1 = Coupling(name = 'GC_1',
                value = '-6*c3G',
                order = {'NP':1})

GC_2 = Coupling(name = 'GC_2',
                value = 'c8Q2G2D1*complex(0,1)',
                order = {'NP':2})

GC_3 = Coupling(name = 'GC_3',
                value = '-(c8Q2G2D2*complex(0,1))',
                order = {'NP':2})

GC_4 = Coupling(name = 'GC_4',
                value = 'c8Q2G2D3*complex(0,1)',
                order = {'NP':2})

GC_5 = Coupling(name = 'GC_5',
                value = 'c8u2G2D1*complex(0,1)',
                order = {'NP':2})

GC_6 = Coupling(name = 'GC_6',
                value = '-(c8u2G2D2*complex(0,1))',
                order = {'NP':2})

GC_7 = Coupling(name = 'GC_7',
                value = 'c8u2G2D3*complex(0,1)',
                order = {'NP':2})

GC_8 = Coupling(name = 'GC_8',
                value = '-G',
                order = {'QCD':1})

GC_9 = Coupling(name = 'GC_9',
                value = 'complex(0,1)*G',
                order = {'QCD':1})

GC_10 = Coupling(name = 'GC_10',
                 value = 'cuG*complex(0,1)*vev*cmath.sqrt(2)',
                 order = {'NP':1,'QED':-1})

GC_11 = Coupling(name = 'GC_11',
                 value = '-(cuG*G*vev*cmath.sqrt(2))',
                 order = {'NP':1,'QCD':1,'QED':-1})

