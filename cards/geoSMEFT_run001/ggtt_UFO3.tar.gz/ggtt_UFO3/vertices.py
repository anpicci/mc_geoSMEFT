# This file was automatically created by FeynRules 2.3.47
# Mathematica version: 13.1.0 for Mac OS X ARM (64-bit) (June 16, 2022)
# Date: Sat 16 Mar 2024 22:18:01


from object_library import all_vertices, Vertex
import particles as P
import couplings as C
import lorentz as L


V_1 = Vertex(name = 'V_1',
             particles = [ P.g, P.g, P.g ],
             color = [ 'f(1,2,3)' ],
             lorentz = [ L.VVV1, L.VVV2 ],
             couplings = {(0,1):C.GC_1,(0,0):C.GC_8})

V_2 = Vertex(name = 'V_2',
             particles = [ P.u__tilde__, P.u, P.g ],
             color = [ 'T(3,2,1)' ],
             lorentz = [ L.FFV1, L.FFV2 ],
             couplings = {(0,0):C.GC_9,(0,1):C.GC_10})

V_3 = Vertex(name = 'V_3',
             particles = [ P.c__tilde__, P.c, P.g ],
             color = [ 'T(3,2,1)' ],
             lorentz = [ L.FFV1, L.FFV2 ],
             couplings = {(0,0):C.GC_9,(0,1):C.GC_10})

V_4 = Vertex(name = 'V_4',
             particles = [ P.t__tilde__, P.t, P.g ],
             color = [ 'T(3,2,1)' ],
             lorentz = [ L.FFV1, L.FFV2 ],
             couplings = {(0,0):C.GC_9,(0,1):C.GC_10})

V_5 = Vertex(name = 'V_5',
             particles = [ P.u__tilde__, P.u, P.g, P.g ],
             color = [ 'd(-1,3,4)*T(-1,2,1)', 'f(-1,3,4)*T(-1,2,1)', 'Identity(1,2)*Identity(3,4)' ],
             lorentz = [ L.FFVV2, L.FFVV3, L.FFVV4, L.FFVV5, L.FFVV6 ],
             couplings = {(2,0):C.GC_2,(0,0):C.GC_4,(1,1):C.GC_3,(2,4):C.GC_5,(0,4):C.GC_7,(1,3):C.GC_6,(1,2):C.GC_11})

V_6 = Vertex(name = 'V_6',
             particles = [ P.c__tilde__, P.c, P.g, P.g ],
             color = [ 'd(-1,3,4)*T(-1,2,1)', 'f(-1,3,4)*T(-1,2,1)', 'Identity(1,2)*Identity(3,4)' ],
             lorentz = [ L.FFVV1, L.FFVV2, L.FFVV4, L.FFVV5, L.FFVV6 ],
             couplings = {(2,1):C.GC_2,(0,1):C.GC_4,(1,0):C.GC_3,(2,4):C.GC_5,(0,4):C.GC_7,(1,3):C.GC_6,(1,2):C.GC_11})

V_7 = Vertex(name = 'V_7',
             particles = [ P.t__tilde__, P.t, P.g, P.g ],
             color = [ 'd(-1,3,4)*T(-1,2,1)', 'f(-1,3,4)*T(-1,2,1)', 'Identity(1,2)*Identity(3,4)' ],
             lorentz = [ L.FFVV1, L.FFVV2, L.FFVV4, L.FFVV5, L.FFVV6 ],
             couplings = {(2,1):C.GC_2,(0,1):C.GC_4,(1,0):C.GC_3,(2,4):C.GC_5,(0,4):C.GC_7,(1,3):C.GC_6,(1,2):C.GC_11})

